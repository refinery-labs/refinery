exports.handler = async (event) => {
    /*
        This is purely a Lambda to act as a placeholder to limit
        the max concurrent instances of Lambda invoked by free-tier users.
    */
    return true;
};
