function handler () {
  export PATH="$(pwd)/bin/:$PATH"
  export PYTHONPATH="$LAMBDA_TASK_ROOT/lib/python2.7/site-packages/"
  EVENT_DATA=$1
  #pip --version 1>&2;
  #virtualenv --version 1>&2;
  #zip --help
  aws --version
  #ls -lisah $PYTHONPATH 1>&2;
  RESPONSE="Echoing request: '$EVENT_DATA'"

  echo $RESPONSE
}
